package pageRank;

public class Node {

	private int docID ;
	
	public Node(int docID) {
		this.docID = docID ;
	}
	
	public int getId() {
		return docID ;
	}
	
    public boolean equals ( Object obj ) {
		return ((Node)obj).getId()==(docID) ;
	}
}