package pageRank;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import duedue.Page;

public class PageRank {

	private Graph graph = new Graph();
	private Map<Node, Double> pagerank_current = new HashMap<Node, Double>();
	private Map<Node, Double> pagerank_new = new HashMap<Node, Double>();
	HashMap<Integer, Integer> urlDoc = new HashMap<Integer, Integer>();

	private double dumping_factor;
	private int iterations;

	public PageRank(double dumping_factor, int iterations) {
		this.dumping_factor = dumping_factor;
		this.iterations = iterations;

		try {
			loadUrlDoc();
			load_data();
			initialize_pagerank();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Map<Node, Double> compute() {
		double teleport = (1.0d - dumping_factor) / graph.countNodes();
		for (int i = 0; i < iterations; i++) {
			double dangling_nodes = 0.0d;
			for (Node node : graph.getNodes()) {
				if (graph.countOutgoingLinks(node) == 0) {
					dangling_nodes += pagerank_current.get(node);
				}
			}
			dangling_nodes = (dumping_factor * dangling_nodes) / graph.countNodes();

			for (Node node : graph.getNodes()) {
				double r = 0.0d;
				for (Node source : graph.getIncomingLinks(node)) {
					r += pagerank_current.get(source) / graph.countOutgoingLinks(source);
				}
				r = dumping_factor * r + dangling_nodes + teleport;
				pagerank_new.put(node, r);
			}
			for (Node node : graph.getNodes()) {
				pagerank_current.put(node, pagerank_new.get(node));
			}
		}

		return pagerank_current;
	}

	private void initialize_pagerank() {
		Double initial_pagerank = (1.0d / graph.countNodes());
		for (Node node : graph.getNodes()) {
			pagerank_current.put(node, initial_pagerank);
		}
	}

	public void loadUrlDoc() {
		File file = new File("url-doc.dat");

		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);

			while (true) {
				Page pair = (Page) ois.readObject();
				if (pair == null)
					break;
				int urlValue = (Integer) pair.getUrlValue();
				int docID = (Integer) pair.getDocName();
				urlDoc.put(urlValue, docID);
			}

			ois.close();
			fis.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void load_data() throws IOException {
		long start = System.currentTimeMillis();

		String pagePath = System.getProperty("user.dir") + File.separator + "CrawledPages" + File.separator;
		File file = new File(pagePath);
		String[] fileNames = file.list();
		JSONParser parser = new JSONParser();
		int count = 0;

		for (String fileName : fileNames) {
			if (fileName.matches("^\\w+?(\\.json)$")) {
				try {
					FileReader reader = new FileReader(pagePath + fileName);
					Object obj = parser.parse(reader);
					JSONObject jsonObject = (JSONObject) obj;

					int docID = Integer.valueOf(fileName.split("\\.")[0]);
					Node source = new Node(docID);
					graph.addNode(source);
					HashSet<Integer> seen = new HashSet<Integer>();

					JSONArray ourgoingLinks = (JSONArray) jsonObject.get("links");
					Iterator<String> iterator = ourgoingLinks.iterator();

					while (iterator.hasNext()) {
						String url = iterator.next();
						int hashValue = BKDRHash(url);
						if (urlDoc.containsKey(hashValue)) {
							int outDocID = urlDoc.get(hashValue);
							if (!seen.contains(outDocID)) { // no multiple links
															// to the same page
								Node destination = new Node(outDocID);
								if (destination != source) { // no self-links
									graph.addNode(destination);
									graph.addLink(source, destination);
								}
								seen.add(outDocID);
							}
						}
					}
					reader.close();
					count++;
					if (count % 1000 == 0)
						System.out.println(count);
				} catch (org.json.simple.parser.ParseException e) {
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println(graph.countLinks());
		System.out.println("Time used:" + (System.currentTimeMillis() - start));

		// just for test;
		// System.out.println("****************************");

		try {
			PrintWriter pw = new PrintWriter("link.txt");

			for(Node node : graph.getNodes()) {
				pw.println(node.getId());
				pw.println("InLink: ");
				for (Node n : graph.getIncomingLinks(node)) {
					pw.print(n.getId() + " ");
				}
				pw.println();
				pw.println("OutLink: ");
				for (Node n : graph.getOutgoingLinks(node)) {
					pw.print(n.getId() + " ");
				}
				pw.println();
			}
			pw.flush();
			pw.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static int BKDRHash(String str) {
		int seed = 131;
		int hash = 0;

		for (int i = 0; i < str.length(); i++) {
			hash = (hash * seed) + str.charAt(i);
		}
		return (hash & 0x7FFFFFFF);
	}

	public static void main(String[] args) {
		PageRank pageRank = new PageRank(0.15, 4);
	}
}